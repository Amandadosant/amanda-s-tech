import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Book, Zap, Users, Target, Lightbulb, Compass, ListChecks, LayoutGrid } from 'lucide-react';

    const FrameworksPage = () => {
      const frameworks = [
        {
          icon: Book,
          title: 'Jobs-to-be-Done (JTBD)',
          description: 'Focus on understanding the "job" a customer is trying to get done, rather than focusing on the product itself. This leads to more innovative and customer-centric solutions.',
        },
        {
          icon: Zap,
          title: 'Lean Startup',
          description: 'A methodology for developing businesses and products that shortens development cycles through a build-measure-learn feedback loop, iterative releases, and validated learning.',
        },
        {
          icon: Users,
          title: 'Design Thinking',
          description: 'A human-centered, iterative process for creative problem-solving. It involves empathizing with users, defining problems, ideating solutions, prototyping, and testing.',
        },
        {
          icon: Target,
          title: 'HEART Framework',
          description: 'A framework by Google for measuring user experience on a large scale. It stands for Happiness, Engagement, Adoption, Retention, and Task Success.',
        },
        {
          icon: Lightbulb,
          title: 'Double Diamond',
          description: 'A design process model that maps the divergent and convergent stages of a design process. It helps designers and teams to understand and structure their creative process.',
        },
        {
          icon: Compass,
          title: 'AARRR Pirate Metrics',
          description: 'A framework for customer lifecycle analysis, focusing on five key metrics: Acquisition, Activation, Retention, Referral, and Revenue. Essential for growth hacking.',
        },
        {
          icon: ListChecks,
          title: 'Feature Prioritization',
          description: 'Techniques like RICE, MoSCoW, and the Kano Model to help teams decide what to build next, balancing user value, business impact, and effort.',
        },
        {
          icon: LayoutGrid,
          title: 'Strategic Frameworks',
          description: 'Models like Porter\'s Five Forces, SWOT Analysis, and the Ansoff Matrix to analyze the competitive landscape and inform long-term product and business strategy.',
        },
      ];

      const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { staggerChildren: 0.1, delayChildren: 0.2 },
        },
      };

      const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: { type: 'spring', stiffness: 100 },
        },
      };

      return (
        <>
          <Helmet>
            <title>Digital Product Frameworks - Amanda's Portfolio</title>
            <meta name="description" content="Explore key digital product frameworks like Jobs-to-be-Done, Lean Startup, and Design Thinking to build better products." />
          </Helmet>
          <div className="pt-24 md:pt-32 pb-24 px-6 overflow-hidden bg-black">
            <motion.section
              initial="hidden"
              animate="visible"
              variants={containerVariants}
              className="max-w-5xl mx-auto text-center mb-20"
            >
              <motion.h1
                variants={itemVariants}
                className="text-5xl md:text-7xl font-black tracking-tighter mb-4 text-white"
              >
                Digital Product Frameworks
              </motion.h1>
              <motion.p
                variants={itemVariants}
                className="text-xl md:text-2xl text-white/70 max-w-3xl mx-auto leading-relaxed"
              >
                A curated collection of powerful methodologies to guide your product strategy and execution.
              </motion.p>
            </motion.section>

            <motion.section
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.1 }}
              className="max-w-6xl mx-auto"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {frameworks.map((framework, index) => (
                  <motion.div
                    key={index}
                    variants={itemVariants}
                    whileHover={{ y: -8, scale: 1.03, transition: { type: 'spring', stiffness: 300 } }}
                    className="bg-white/5 border border-[var(--color-border-subtle)] rounded-2xl p-8 flex flex-col"
                  >
                    <div className="p-3 bg-[var(--color-highlight-blue)]/20 rounded-lg border border-[var(--color-highlight-blue)]/30 self-start mb-5">
                      <framework.icon size={28} className="text-[var(--color-highlight-blue)]" />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-3">{framework.title}</h3>
                    <p className="text-white/70 text-base leading-relaxed">{framework.description}</p>
                  </motion.div>
                ))}
              </div>
            </motion.section>
          </div>
        </>
      );
    };

    export default FrameworksPage;