import React, { useState, useEffect } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion, AnimatePresence } from 'framer-motion';
    import { ArrowUpRight, Loader2, Mail, Lightbulb, ClipboardList, Layers, LineChart, BarChart, Users, BrainCircuit, BookOpen, TrendingUp, Zap, DollarSign, Clock } from 'lucide-react';
    import { toast } from '@/components/ui/use-toast';
    import About from '@/components/About';
    import { supabase } from '@/lib/customSupabaseClient';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';

    const HomePage = () => {
      const [isSubmitting, setIsSubmitting] = useState(false);
      const [activeService, setActiveService] = useState(0);

      const initialContent = {
        name: "Amanda",
        tagline: "Your Digital Product Expert",
        heroSubheadline: "Designing, building, and scaling digital products that solve real problems and create measurable growth. From first concept to global scale, every stage is led with strategy and precision.",
        heroButton: "Start a Project",
        about: {
          name: "Amanda",
          title: "About Me",
          intro: "I collaborate with companies and founders to shape, build, and scale digital products that drive growth and deliver measurable business impact. With a business-first approach, I connect market opportunities with user needs to deliver value.",
          journeyTitle: "My Journey",
          journeyText: "I partner with organizations to validate opportunities, define product vision, and deliver digital products that accelerate growth and create lasting business value.",
          imageUrl: "https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/2c6def4cb4c408f90ebcca917be4aa27.jpg",
          email: "amanda@amandatech.site",
          capabilitiesTitle: "Core Capabilities",
          capabilities: [{
            iconName: 'Rocket',
            text: 'Strategic Product Leadership'
          }, {
            iconName: 'Lightbulb',
            text: 'SaaS Product Discovery & Delivery'
          }, {
            iconName: 'BarChart',
            text: 'Entrepreneurial Growth & Market Expansion'
          }, {
            iconName: 'Users',
            text: 'Executive & C-Level Stakeholder Alignment'
          }]
        },
        portfolio: {
          title: "Selected Strategic Projects",
          subtitle: "Trusted by Fortune Global 500 & leading enterprises",
          items: [{
            company: 'Itaú Unibanco (Fortune Global 500)',
            title: 'Transforming Financial Services Through Digital Innovation',
            description: "I led digital transformation initiatives at one of the world’s largest financial institutions, shaping product vision and delivering large-scale solutions for millions of users. The work improved service quality, reduced complaints, and mitigated risks, contributing to projects that generated over €370 million in results and supported a portfolio worth around €2.6 billion.",
            imageUrl: "https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/2c7ddc074dd9ad574e09a5d521899d24.png",
            link: "https://amandatech.site/insights/itau-unibanco-legacy-system-design-thinking"
          }, {
            title: 'Designing Digital Strategies That Accelerate Market Impact',
            company: 'Ricam Consulting (Strategic Advisory for Leading Enterprises)',
            description: "At Ricam Consulting, I partnered with executive teams to shape digital strategies that connected market opportunities with product direction and business outcomes. My work included leading research and validation initiatives, defining product positioning, and designing strategic roadmaps to accelerate growth. These initiatives helped organizations strengthen their competitive edge, launch impactful digital solutions, and scale in dynamic markets.",
            imageUrl: "https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/3d0dd68a83c4a3a7fb7325b14f12cb25.png",
            link: "https://amandatech.site/insights/latin-america-influencer-ricardo-amorim"
          }, {
            title: 'Scaling a Global SaaS Platform for Growth',
            company: 'Meetingselect (Global Company with Worldwide Reach)',
            description: "At Meetingselect, I built and scaled the global evolution of a B2B SaaS platform, aligning product strategy with business goals and driving expansion across key markets. I structured long-term product roadmaps, orchestrated cross-functional collaboration, and guided the full product lifecycle from discovery to launch. This strategic work strengthened the company’s value proposition, expanded its customer base worldwide, and generated measurable growth in engagement and revenue.",
            imageUrl: "https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/401a72b04c0e4966c3c1ffe595091cc5.webp",
            link: "https://amandatech.site/insights/jobs-to-be-done-right-problem"
          }]
        },
        services: {
          title: "What I Offer",
          subtitle: "Expertise to drive your product forward",
          items: [{
            title: 'Product Strategy',
            description: 'Defining vision, goals, and strategic roadmaps for impactful digital products.',
            iconComponent: 'Lightbulb'
          }, {
            title: 'Roadmap Development',
            description: 'Crafting detailed product roadmaps that align with business objectives and user needs.',
            iconComponent: 'ClipboardList'
          }, {
            title: 'UX/UI Oversight',
            description: 'Ensuring user-centric design and seamless experiences throughout the product lifecycle.',
            iconComponent: 'Layers'
          }, {
            title: 'Entrepreneurial Growth & Market Expansion',
            description: 'Driving growth initiatives and market expansion strategies for new and existing products.',
            iconComponent: 'BarChart'
          }, {
            title: 'Executive & C-Level Stakeholder Alignment',
            description: 'Facilitating alignment and communication between product initiatives and executive leadership.',
            iconComponent: 'Users'
          }, {
            title: 'Market Research',
            description: 'Identifying market trends, competitive landscapes, and user insights to drive product innovation.',
            iconComponent: 'LineChart'
          }]
        },
        contact: {
          title: "Let's Connect",
          subtitle: "Ready to build the next great product?",
          form: {
            nameLabel: "Name",
            emailLabel: "Email",
            messageLabel: "Message",
            submitButton: "Send Message"
          }
        },
      };
      
      const [content, setContent] = useState(initialContent);

      useEffect(() => {
        setContent(initialContent);
        localStorage.setItem('websiteContent', JSON.stringify(initialContent));
      }, []);

      const scrollToSection = (id) => {
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      };

      const handleContactSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        const formData = new FormData(e.target);
        const name = formData.get('name');
        const email = formData.get('email');
        const message = formData.get('message');

        const { error } = await supabase.from("Amanda's form").insert([{ name, email, message }]);

        if (error) {
          console.error('Supabase error:', error.message);
          toast({
            variant: "destructive",
            title: "Uh oh! Something went wrong.",
            description: "There was a problem with your request. Please try again.",
          });
        } else {
          toast({
            title: "Message Sent! 🎉",
            description: "Thanks for reaching out! I'll get back to you soon.",
          });
          e.target.reset();
        }
        setIsSubmitting(false);
      };
      
      const portfolioImages = [
        "https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/2c7ddc074dd9ad574e09a5d521899d24.png",
        "https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/3d0dd68a83c4a3a7fb7325b14f12cb25.png",
        "https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/401a72b04c0e4966c3c1ffe595091cc5.webp"
      ];
      
      const portfolioAlts = [
        "Itaú Unibanco logo in a futuristic office with digital lines, symbolizing digital banking transformation and innovation.",
        "Ricardo Amorim, a Forbes-recognized influencer, in a professional setting, symbolizing digital strategy and high-level consulting.",
        "Meetingselect platform interface displayed on a laptop, showcasing venue selection and event management tools, symbolizing global platform expansion and digital product delivery."
      ];

      const IconComponents = { Lightbulb, ClipboardList, Layers, LineChart, BarChart, Users };

      const stats = [
        {
          value: "€370M+",
          label: "Business impact generated through digital transformation initiatives.",
          icon: DollarSign
        },
        {
          value: "40%",
          label: "Reduction in manual processes at enterprise scale.",
          icon: Zap
        },
        {
          value: "€2.6B",
          label: "Portfolio supported through automation and process redesign.",
          icon: TrendingUp
        },
        {
          value: "10+ years",
          label: "Leading digital product strategy across LATAM and Europe.",
          icon: Clock
        }
      ];

      return (
        <>
          <Helmet>
            <title>{`${content.name} - ${content.tagline}`}</title>
            <meta name="description" content={`Portfolio of ${content.name} - ${content.tagline}.`} />
          </Helmet>
          
          <main className="overflow-x-hidden bg-black">
            <section id="hero" className="relative min-h-screen flex items-center justify-center pt-32 pb-24 px-6">
              <div className="absolute inset-0 z-0 opacity-10 bg-grid-pattern"></div>
              <div className="absolute inset-0 z-[-1] bg-hero-gradient"></div>
              <div className="relative z-10 max-w-4xl mx-auto text-center">
                <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: "easeOut" }}>
                  <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-6 leading-tight text-white">{content.tagline}</h1>
                  <p className="text-xl md:text-2xl text-white/70 mb-10 max-w-3xl mx-auto leading-relaxed">{content.heroSubheadline}</p>
                  <Button size="lg" onClick={() => scrollToSection('contact')} aria-label="Start a Project">
                    {content.heroButton} <ArrowUpRight size={24} className="ml-2" />
                  </Button>
                </motion.div>
              </div>
            </section>

            <section id="results" className="py-24 px-6 border-t border-white/10">
              <div className="max-w-7xl mx-auto">
                <motion.div 
                  initial={{ opacity: 0, y: 50 }} 
                  whileInView={{ opacity: 1, y: 0 }} 
                  viewport={{ once: true, amount: 0.3 }} 
                  className="mb-16 text-center"
                >
                  <h2 className="text-4xl md:text-5xl font-extrabold tracking-tighter mb-4 text-[var(--color-highlight-blue)]">Results in Numbers</h2>
                  <p className="text-lg md:text-xl text-white/70 max-w-3xl mx-auto leading-relaxed">Driving measurable impact through strategy, automation, and global product leadership.</p>
                </motion.div>
                <motion.div 
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ staggerChildren: 0.15 }}
                >
                  {stats.map((stat, index) => (
                    <motion.div 
                      key={index}
                      className="relative p-8 bg-white/5 rounded-2xl border border-transparent overflow-hidden group transition-all duration-300 hover:border-[var(--color-highlight-blue)]/50 hover:bg-[var(--color-highlight-blue)]/10"
                      variants={{
                        hidden: { opacity: 0, y: 30 },
                        visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
                      }}
                    >
                      <div className="absolute bottom-0 left-0 w-full h-1 bg-[var(--color-highlight-blue)]/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-md"></div>
                      <div className="relative z-10">
                        <p className="text-5xl md:text-6xl font-black text-white mb-4">{stat.value}</p>
                        <p className="text-base text-gray-300 leading-relaxed">{stat.label}</p>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            </section>

            <section id="portfolio" className="py-24 px-6 border-t border-b border-white/10">
              <div className="max-w-7xl mx-auto w-full">
                <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} className="mb-16 text-center">
                  <h2 className="text-4xl md:text-5xl font-extrabold tracking-tighter mb-4 text-white">{content.portfolio.title}</h2>
                  <p className="text-lg md:text-xl text-white/70 max-w-2xl mx-auto font-medium leading-relaxed">{content.portfolio.subtitle}</p>
                </motion.div>
                <div className="space-y-20">
                  {content.portfolio.items.map((item, index) => (
                    <motion.div 
                      key={index} 
                      className={`grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-center`}
                      initial={{ opacity: 0, y: 50 }} 
                      whileInView={{ opacity: 1, y: 0 }} 
                      viewport={{ once: true, amount: 0.3 }} 
                      transition={{ duration: 0.7, ease: "easeOut" }}
                    >
                      <div className={`relative aspect-video rounded-3xl overflow-hidden shadow-2xl shadow-black/40 bg-black/20 ${index % 2 === 1 ? 'md:order-2' : ''}`}>
                        <img src={portfolioImages[index]} alt={portfolioAlts[index]} className="w-full h-full object-contain" />
                      </div>
                      <div className={index % 2 === 1 ? 'md:order-1' : ''}>
                        <span className="text-[var(--color-highlight-blue)] font-semibold uppercase tracking-wider text-sm mb-3 block">{item.company}</span>
                        <h3 className="text-3xl md:text-4xl font-bold leading-tight mb-5">{item.title}</h3>
                        <p className="text-white/70 text-base leading-relaxed">{item.description}</p>
                        {item.link && (
                          <a href={item.link} className="inline-block mt-6">
                            <Button aria-label={`Read more about ${item.title}`}>
                              Read More
                            </Button>
                          </a>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>

            <About content={content.about} scrollToContact={scrollToSection} />

            <section id="services" className="py-24 px-6 bg-black relative">
              <div className="absolute inset-x-0 top-0 h-[500px] bg-gradient-to-b from-[var(--color-main-blue)]/10 to-transparent blur-3xl"></div>
              <div className="max-w-7xl mx-auto w-full relative">
                <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} className="mb-16 text-center">
                  <h2 className="text-4xl md:text-5xl font-extrabold tracking-tighter mb-4 text-white">{content.services.title}</h2>
                  <p className="text-lg md:text-xl text-white/70 max-w-2xl mx-auto font-medium leading-relaxed">{content.services.subtitle}</p>
                </motion.div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                  <div className="col-span-1 flex flex-col gap-2">
                    {content.services.items.map((service, index) => {
                      const Icon = IconComponents[service.iconComponent];
                      const isActive = activeService === index;
                      return (
                        <motion.div 
                          key={index} 
                          onClick={() => setActiveService(index)} 
                          className={`relative p-5 rounded-2xl cursor-pointer overflow-hidden transition-all duration-300 group ${isActive ? 'bg-white/10 border-[var(--color-highlight-blue)]/50' : 'bg-transparent border-white/10 hover:bg-white/5 hover:border-white/20'}`} 
                          whileHover={{ scale: 1.01 }}
                          layout
                        >
                          <div className="relative z-10 flex items-center gap-4">
                            {Icon && <Icon size={24} className={`flex-shrink-0 transition-colors duration-300 ${isActive ? 'text-[var(--color-highlight-blue)]' : 'text-white/60 group-hover:text-white'}`} />}
                            <h3 className={`text-lg font-bold transition-colors duration-300 ${isActive ? 'text-white' : 'text-white/80 group-hover:text-white'}`}>{service.title}</h3>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                  <div className="col-span-1 lg:col-span-2 relative min-h-[350px] lg:min-h-0">
                    <AnimatePresence mode="wait">
                      <motion.div 
                        key={activeService} 
                        initial={{ opacity: 0, x: 30 }}
                        animate={{ opacity: 1, x: 0 }} 
                        exit={{ opacity: 0, x: -30 }} 
                        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                        className="absolute inset-0 p-8 md:p-12 flex flex-col justify-center bg-white/5 border border-white/10 rounded-3xl backdrop-blur-lg"
                      >
                        <div className="p-3 bg-[var(--color-highlight-blue)]/20 rounded-full mb-5 self-start border border-[var(--color-highlight-blue)]/50">
                          {React.createElement(IconComponents[content.services.items[activeService].iconComponent], { size: 32, className: "text-[var(--color-highlight-blue)]" })}
                        </div>
                        <h3 className="text-3xl md:text-4xl font-black tracking-tighter mb-3">{content.services.items[activeService].title}</h3>
                        <p className="text-lg text-white/70 leading-relaxed max-w-prose">{content.services.items[activeService].description}</p>
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </section>

            <section id="frameworks" className="py-24 px-6 border-t border-white/10">
              <div className="max-w-7xl mx-auto w-full">
                <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} className="mb-16 text-center">
                  <h2 className="text-4xl md:text-5xl font-extrabold tracking-tighter mb-4 text-white">Frameworks & Insights</h2>
                  <p className="text-lg md:text-xl text-white/70 max-w-2xl mx-auto font-medium leading-relaxed">Unlock growth with proven strategies and tailored advice.</p>
                </motion.div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
                  <motion.div 
                    initial={{ opacity: 0, x: -50 }} 
                    whileInView={{ opacity: 1, x: 0 }} 
                    viewport={{ once: true, amount: 0.3 }}
                    className="bg-gradient-to-br from-[var(--color-main-blue)]/30 to-black/30 p-8 md:p-12 rounded-3xl border border-[var(--color-main-blue)]/30 flex flex-col items-center text-center"
                  >
                    <div className="p-4 bg-[var(--color-main-blue)]/20 rounded-full mb-6 border border-[var(--color-main-blue)]/50">
                      <BrainCircuit size={40} className="text-[var(--color-main-blue)]" />
                    </div>
                    <h3 className="text-3xl font-bold mb-4">Book an Insight Session</h3>
                    <p className="text-white/70 mb-8 max-w-md text-base leading-relaxed">Get personalized, one-on-one guidance to tackle your product's biggest challenges and unlock its full potential.</p>
                    <Button size="lg" onClick={() => scrollToSection('contact')} aria-label="Schedule an Insight Session">
                      Schedule Now <ArrowUpRight size={24} className="ml-2" />
                    </Button>
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0, x: 50 }} 
                    whileInView={{ opacity: 1, y: 0 }} 
                    viewport={{ once: true, amount: 0.3 }}
                    className="bg-white/5 p-8 md:p-12 rounded-3xl border border-white/10 h-full flex flex-col items-center text-center"
                  >
                    <div className="p-4 bg-white/10 rounded-full mb-6 border border-white/20">
                      <BookOpen size={40} className="text-white/80" />
                    </div>
                    <h3 className="text-3xl font-bold mb-4">Digital Product Frameworks</h3>
                    <p className="text-white/70 mb-8 max-w-md text-base leading-relaxed">Explore a curated collection of frameworks and methodologies to build better products, faster.</p>
                    <Link to="/frameworks">
                      <Button variant="outline" size="lg" className="bg-white/10 border-white/20 hover:bg-white/20" aria-label="Explore Digital Product Frameworks">
                        Explore Frameworks <ArrowUpRight size={24} className="ml-2" />
                      </Button>
                    </Link>
                  </motion.div>
                </div>
              </div>
            </section>

            <section id="contact" className="py-24 px-6">
              <div className="max-w-3xl mx-auto w-full">
                <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} className="mb-12 text-center">
                  <h2 className="text-4xl md:text-5xl font-extrabold tracking-tighter mb-4 text-white">{content.contact.title}</h2>
                  <p className="text-lg md:text-xl text-white/70 max-w-2xl mx-auto font-medium leading-relaxed">{content.contact.subtitle}</p>
                </motion.div>
                <motion.form initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.2 }} onSubmit={handleContactSubmit} className="bg-white/5 p-8 md:p-12 rounded-2xl border border-white/10 space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-white/70 mb-2">{content.contact.form.nameLabel}</label>
                      <input type="text" id="name" name="name" required className="form-input" placeholder="Your name" />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-white/70 mb-2">{content.contact.form.emailLabel}</label>
                      <input type="email" id="email" name="email" required className="form-input" placeholder="your@email.com" />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-white/70 mb-2">{content.contact.form.messageLabel}</label>
                    <textarea id="message" name="message" required rows={5} className="form-input resize-none" placeholder="Tell me about your project..."></textarea>
                  </div>
                  <Button type="submit" size="lg" disabled={isSubmitting} className="w-full" aria-label="Send contact message">
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Mail size={20} className="mr-2" />
                        {content.contact.form.submitButton}
                      </>
                    )}
                  </Button>
                </motion.form>
              </div>
            </section>
          </main>
        </>
      );
    };

    export default HomePage;