import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { CheckCircle2, Award } from 'lucide-react';

    const ExpertisePage = () => {
      const skills = [
        "Product Strategy", 
        "AI-Driven Product Innovation",
        "Go-to-Market Execution", 
        "SaaS Product Development", 
        "End-to-End Delivery", 
        "Agile Product Ownership", 
        "Growth Enablement", 
        "Customer Journey Mapping", 
        "NPS Strategy & Measurement", 
        "Design Thinking", 
        "Innovation Frameworks"
      ];
      
      const tools = [
        { name: "AI & Productivity Tools", desc: "(ChatGPT, Copilot, Notion AI, Midjourney, Gemini)" },
        { name: "Jira, Confluence, Trello", desc: "" }, 
        { name: "HubSpot", desc: "(CRM, Marketing Automation, CMS)" }, 
        { name: "Microsoft Excel", desc: "(Data Analysis and Reporting)" }, 
        { name: "Microsoft PowerPoint", desc: "(Pitch Decks, Product Roadmaps, Executive Presentations)" },
        { name: "Canva", desc: "(Visual Communication and Product Presentations)" },
        { name: "Journey Mapping Tools", desc: "(Miro, Smaply, UXPressia)" }, 
        { name: "NPS Analysis Tools", desc: "(Qualtrics, Delighted, Typeform)" }, 
        { name: "Design Thinking Tools", desc: "(Figma, Miro, Notion, Service Blueprint Templates)" }
      ];

      const education = [
        "Master’s in Business Management – ESPM", 
        "Digital Transformation – University of Virginia", 
        "Blockchain Technologies – INSEAD", 
        "Lean Six Sigma Green Belt", 
        "Product Owner Certified"
      ];

      const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { staggerChildren: 0.1, delayChildren: 0.2 }
        }
      };

      const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: { type: "spring", stiffness: 100 }
        }
      };

      return (
        <>
          <Helmet>
            <title>Expertise - Digital Product Expert</title>
            <meta name="description" content="Digital product expert in the Netherlands, specializing in SaaS strategy, design thinking, and go-to-market execution." />
            <meta name="keywords" content="digital product expert, design thinking Netherlands, SaaS strategy, customer journey mapping, NPS product measurement, go-to-market execution, Agile product ownership, Figma UX tools, HubSpot CRM" />
          </Helmet>

          <div className="pt-24 md:pt-32 pb-24 px-6 overflow-hidden">
            <motion.section initial="hidden" animate="visible" variants={containerVariants} className="max-w-5xl mx-auto text-center mb-20">
              <motion.h1 variants={itemVariants} className="text-5xl md:text-7xl font-black tracking-tighter mb-4 leading-[1.3] pb-3 text-white">
                Expertise
              </motion.h1>
              <motion.p variants={itemVariants} className="text-xl md:text-2xl text-[var(--color-secondary-text)] max-w-3xl mx-auto leading-relaxed mb-8">
                Building and scaling digital products that solve real problems and deliver measurable growth.
              </motion.p>
            </motion.section>

            <motion.section variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }} className="max-w-5xl mx-auto mb-20">
              <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-extrabold tracking-tight text-[var(--color-highlight-blue)] text-center mb-6 leading-[1.3] pb-2">Strategic Product Leadership</motion.h2>
              <motion.p variants={itemVariants} className="text-lg text-[var(--color-secondary-text)] leading-relaxed text-center max-w-4xl mx-auto mb-8">
                Expert in designing, building, and scaling digital and AI-driven products that address complex business challenges and accelerate growth. Experienced in leading the full product life cycle from discovery and market validation to launch and scale for both Fortune 500 companies and fast-growing startups. Focused on aligning product strategy with business objectives, leveraging AI, data insights, and Copilot tools to create user-centric solutions and deliver measurable outcomes across global markets.
              </motion.p>
            </motion.section>

            <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 mb-20">
              <motion.section variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }}>
                <motion.h3 variants={itemVariants} className="text-3xl font-bold mb-6 leading-[1.3] pb-2">Core Skills & Specializations</motion.h3>
                <motion.ul variants={containerVariants} className="space-y-3">
                  {skills.map(skill => (
                    <motion.li key={skill} variants={itemVariants} className="flex items-center gap-3 text-lg leading-relaxed">
                      <CheckCircle2 className="h-6 w-6 text-[var(--color-highlight-blue)] flex-shrink-0" />
                      <span>{skill}</span>
                    </motion.li>
                  ))}
                </motion.ul>
              </motion.section>
              <motion.section variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }}>
                <motion.h3 variants={itemVariants} className="text-3xl font-bold mb-6 leading-[1.3] pb-2">Tools & Platforms</motion.h3>
                <motion.ul variants={containerVariants} className="space-y-3">
                  {tools.map(tool => (
                    <motion.li key={tool.name} variants={itemVariants} className="flex items-start gap-3 text-lg leading-relaxed">
                      <CheckCircle2 className="h-6 w-6 text-[var(--color-highlight-blue)] flex-shrink-0 mt-1" />
                      <div>
                        <strong>{tool.name}</strong>
                        {tool.desc && <span className="text-white/60 ml-1">{tool.desc}</span>}
                      </div>
                    </motion.li>
                  ))}
                </motion.ul>
              </motion.section>
            </div>

            <motion.section variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }} className="max-w-5xl mx-auto">
              <motion.h3 variants={itemVariants} className="text-3xl font-bold mb-8 text-center leading-[1.3] pb-2">Education & Certifications</motion.h3>
              <motion.ul variants={containerVariants} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 text-center">
                {education.map(cert => (
                  <motion.li key={cert} variants={itemVariants} whileHover={{ scale: 1.05, y: -5, transition: { type: "spring", stiffness: 300 } }} className="bg-white/5 border border-[var(--color-border-subtle)] rounded-lg p-6 cursor-default flex flex-col items-center justify-center min-h-[160px] leading-relaxed">
                    <Award className="h-8 w-8 text-[var(--color-highlight-blue)] mb-3" />
                    <span className="font-semibold text-lg">{cert}</span>
                  </motion.li>
                ))}
              </motion.ul>
            </motion.section>
          </div>
        </>
      );
    };

    export default ExpertisePage;