import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { ArrowUpRight } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';

    const InsightsPage = () => {
        const articles = [
        {
          title: 'Case Study: How Design Thinking Reshaped a Legacy System at Itaú Unibanco',
          date: 'August 22, 2025',
          description: 'Transforming Financial Services Through Digital Innovation: I led digital transformation initiatives at one of the world’s largest financial institutions, shaping product vision and delivering large-scale solutions for millions of users.',
          category: 'Case Studies',
          link: '/insights/itau-unibanco-legacy-system-design-thinking',
          image: 'https://images.unsplash.com/photo-1590283147000-f51a60701947?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          size: 'large',
        },
        {
          title: 'The Art of Feature Prioritization: A Deep Dive into RICE',
          date: 'October 16, 2025',
          description: 'Beyond the formula, we explore the nuances of using the RICE framework to make data-informed decisions that align with your product vision and user needs.',
          category: 'Product Management',
          link: '/insights/the-art-of-feature-prioritization-rice',
          image: 'https://images.unsplash.com/photo-1557804506-669a67965da0?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          size: 'small',
        },
        {
          title: 'What Working with Latin America’s Most Followed Business Influencer Taught Me',
          date: 'October 23, 2025',
          description: 'Lessons from my time at Ricam Consulting with Ricardo Amorim on clarity, consistency, and how strategic thinking translates into measurable digital transformation results.',
          category: 'Leadership',
          link: '/insights/latin-america-influencer-ricardo-amorim',
          image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          size: 'small',
        },
        {
          title: 'Scaling a SaaS Platform: Lessons from Real Growth Stories',
          date: 'October 02, 2025',
          description: 'Explore how now-leading B2B SaaS companies like Slack, HubSpot, and Notion scaled effectively.',
          category: 'Strategy',
          link: '/insights/saas-scaling-growth-lessons',
          image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8MHxwaG90by1wYWdlfHx8fA%3D%3D',
          size: 'small',
        },
        {
          title: 'Jobs-to-be-Done: Are You Solving the Right Problem?',
          date: 'August 10, 2025',
          description: 'Understand the core principles of Jobs-to-be-Done theory and how it helps product teams build solutions that truly resonate with customer needs.',
          category: 'Product Management',
          link: '/insights/jobs-to-be-done-right-problem',
          image: 'https://images.unsplash.com/photo-1521737711867-ee1ab9c9507e?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          size: 'large',
        },
         {
          title: 'Lessons Learned from an AI Product Launch',
          date: 'September 16, 2025',
          description: 'Key takeaways from bringing an AI-driven product to market and insights on navigating the hype.',
          category: 'AI',
          link: '/insights/ai-product-launch-lessons',
          image: 'https://images.unsplash.com/photo-1573496359142-b8d87734b584?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          size: 'small',
        },
      ];

      const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
      };

      const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } },
      };

      const ArticleCard = ({ article }) => {
        const isLarge = article.size === 'large';
        const cardClasses = `
          relative rounded-3xl overflow-hidden p-8 flex flex-col justify-end group
          min-h-[450px] shadow-2xl shadow-black/30
          ${isLarge ? 'md:col-span-2' : 'md:col-span-1'}
        `;

        return (
          <motion.div
            variants={itemVariants}
            className={cardClasses}
            whileHover={{ y: -8, transition: { type: 'spring', stiffness: 300 } }}
          >
            <div className="absolute inset-0 bg-cover bg-center transition-transform duration-500 ease-in-out group-hover:scale-105" style={{ backgroundImage: `url(${article.image})` }}></div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent"></div>
            <div className="relative z-10 text-white">
              <span className="block text-sm font-semibold uppercase tracking-wider text-white/70 mb-2">{article.category}</span>
              <Link to={article.link}>
                <h2 className="text-2xl md:text-3xl font-bold leading-tight mb-4 transition-colors duration-300 hover:text-[var(--color-highlight-blue)]">{article.title}</h2>
              </Link>
              <p className="text-white/80 leading-relaxed mb-6 hidden md:block">{article.description}</p>
              <Link to={article.link} className="inline-block mt-6">
                <Button aria-label={`Read more about ${article.title}`}>
                  Read More <ArrowUpRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </motion.div>
        );
      };

      return (
        <>
          <Helmet>
            <title>Insights & Articles - Amanda's Portfolio</title>
            <meta name="description" content="A collection of thoughts, analyses, and case studies on building impactful digital products." />
          </Helmet>
          <div className="pt-32 pb-24 px-6 bg-[var(--color-main-bg)] text-[var(--color-secondary-text)] relative overflow-hidden">
            <div className="absolute inset-0 bg-grid-pattern opacity-50 z-0"></div>
            <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-[var(--color-main-blue)]/10 to-transparent -translate-y-1/2 blur-3xl z-0"></div>

            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="max-w-7xl mx-auto relative z-10"
            >
              <motion.header variants={itemVariants} className="text-center mb-20">
                <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-[var(--color-heading-text)]">
                  Insights & Articles
                </h1>
                <p className="text-xl md:text-2xl max-w-3xl mx-auto mt-4 leading-relaxed text-[var(--color-secondary-text)]">
                  A collection of thoughts, analyses, and case studies on building impactful digital products.
                </p>
              </motion.header>

              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              >
                {articles.map((article, index) => (
                  <ArticleCard key={index} article={article} />
                ))}
              </motion.div>
            </motion.div>
          </div>
        </>
      );
    };

    export default InsightsPage;