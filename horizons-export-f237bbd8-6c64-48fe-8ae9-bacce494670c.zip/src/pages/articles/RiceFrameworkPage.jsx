import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Link } from 'react-router-dom';
    import { useToast } from '@/components/ui/use-toast';
    import { ArrowRight, Calendar, User, Tag } from 'lucide-react';
    import ArticleImage from '@/components/ArticleImage';

    const RiceFrameworkPage = () => {
      const { toast } = useToast();
      const handleCtaClick = (e) => {
        e.preventDefault();
        toast({
          title: '🚧 Feature in Progress!',
          description: "Full articles are coming soon. You can request this feature in your next prompt! 🚀",
        });
      };

      const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { staggerChildren: 0.1, delayChildren: 0.2 },
        },
      };

      const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: { type: 'spring', stiffness: 100 },
        },
      };

      return (
        <>
          <Helmet>
            <title>RICE Framework in Product Management: How to Prioritize Features Strategically</title>
            <meta name="description" content="Learn how to apply the RICE framework to prioritize features effectively. Real lessons from Itaú’s digital banking transformation, Intercom, and Airbnb." />
          </Helmet>
          <div className="pt-24 md:pt-32 pb-24 px-6 overflow-hidden bg-black text-white">
            <motion.article
              initial="hidden"
              animate="visible"
              variants={containerVariants}
              className="max-w-3xl mx-auto"
            >
              <motion.header variants={itemVariants} className="mb-12 text-center">
                <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6 text-white">
                  RICE Framework in Product Management: How to Prioritize Features Strategically
                </h1>
                <div className="flex justify-center items-center flex-wrap gap-x-6 gap-y-2 text-white/60 text-sm">
                  <div className="flex items-center gap-2">
                    <User size={14} />
                    <span>Amanda</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={14} />
                    <time dateTime="2025-10-15">October 15, 2025</time>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag size={14} />
                    <span>Product Management, Strategy, Frameworks</span>
                  </div>
                </div>
              </motion.header>

              <ArticleImage 
                src="https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/istockphoto-1216130190-612x612-z7VPl.jpg"
                alt="digital product team prioritizing roadmap"
                caption="A product team using the RICE framework to make data-informed decisions."
              />

              <motion.div variants={itemVariants} className="prose prose-invert lg:prose-xl max-w-none mx-auto text-[var(--color-secondary-text)] space-y-8">
                <p className="lead text-xl md:text-2xl !text-white/90 leading-relaxed">
                  Feature prioritization is one of the hardest challenges in product management. Too many ideas, limited time, and constant pressure to deliver impact make decision-making complex. The RICE framework offers a clear structure to evaluate features based on reach, impact, confidence, and effort. It transforms prioritization from a guessing game into a strategic discussion. Its full potential emerges when applied within real business contexts, as seen in Itaú’s digital banking transformation between 2015 and 2019, and in global companies such as Intercom and Airbnb, where data and human insight guided roadmap decisions.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">1. The Foundation of the RICE Framework</h2>
                <p className="text-base leading-relaxed">
                  RICE combines four essential dimensions that help teams evaluate what to build next. Reach defines how many people will be affected. Impact measures how much value each person receives. Confidence expresses how certain the team is about the assumptions. Effort estimates the time and resources required.
                </p>
                <p className="text-base leading-relaxed">
                  At Intercom, RICE became central to roadmap discussions. Instead of debating opinions, teams analyzed how many customers a feature could reach and what measurable difference it would bring. At Itaú, this approach was used during the digital banking rollout. The paperless onboarding feature reached millions of users, but it required evaluating operational effort and regulatory complexity. Using RICE principles helped balance customer reach with feasibility and prevented months of rework.
                </p>
                
                <ArticleImage 
                  src="https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/rice-lahch.png"
                  alt="RICE framework diagram"
                  caption="The four components of RICE: Reach, Impact, Confidence, and Effort."
                />

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">2. Why Context Defines Priority</h2>
                <p className="text-base leading-relaxed">
                  A feature can score well on RICE and still be the wrong decision. At Atlassian, the Confluence team learned that a feature with a high reach but low strategic value distracted focus from long-term goals. The same applies to banking innovation.
                </p>
                <p className="text-base leading-relaxed">
                  During Itaú’s transformation, highly visible requests such as redesigns of the app interface often scored high on reach. However, the real strategic impact came from automation behind the scenes: digital signatures, workflow APIs, and cross-channel authentication. When RICE is applied with a clear strategy in mind, it becomes a tool for alignment rather than a numerical exercise.
                </p>
                <blockquote className="border-l-4 border-[var(--color-highlight-blue)] pl-6 py-2 text-xl italic text-white my-8">
                  <p>Frameworks organize thinking, but strategy defines direction.</p>
                </blockquote>
                
                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">3. When Data Meets Empathy</h2>
                <p className="text-base leading-relaxed">
                  RICE gives structure to decisions, but it cannot replace empathy. At Airbnb, small UX changes like improving verification flows increased user trust and delivered more impact than high-scoring technical releases. At Itaú, quantitative models suggested prioritizing transactional updates. However, qualitative insights from interviews showed that improving copywriting and error handling built trust and reduced abandonment during onboarding.
                </p>
                <p className="text-base leading-relaxed">
                  Combining data with empathy transforms prioritization from mechanical analysis into meaningful design.
                </p>
                
                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">4. Alignment Over Arithmetic</h2>
                <p className="text-base leading-relaxed">
                  The greatest value of RICE comes from alignment. When product, design, and engineering teams discuss each factor openly, the conversation shifts from urgency to value. At Itaú, that mindset helped coordinate prioritization across more than a dozen agile teams. Instead of chasing numbers, teams debated assumptions together, built transparency, and accelerated delivery.
                </p>
                <p className="text-base leading-relaxed">
                  The score was only the beginning. The real progress came from shared understanding.
                </p>
                
                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">Conclusion</h2>
                <p className="text-base leading-relaxed">
                  RICE blends structure and strategy to bring clarity to product decisions. It encourages teams to ask the right questions before committing to work. Used with intention, it is not about ranking, but about reasoning. Whether scaling a SaaS product or transforming a century-old bank, the goal is the same: prioritize what creates measurable impact and align teams around it.
                </p>
              </motion.div>

              <motion.div variants={itemVariants} className="mt-16 pt-8 border-t border-[var(--color-border-subtle)] bg-white/5 p-8 rounded-xl text-center">
                <Link to="/insights/scaling-a-saas-platform" className="group inline-flex items-center font-bold text-[var(--color-highlight-blue)] hover:text-[var(--color-hover-blue)] transition-colors text-lg">
                  Read next: Scaling a SaaS Platform: Lessons from Real Growth Stories
                  <ArrowRight size={20} className="ml-2 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            </motion.article>
          </div>
        </>
      );
    };
    export default RiceFrameworkPage;