import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Link } from 'react-router-dom';
    import { ArrowRight, Calendar, User, Tag } from 'lucide-react';
    import ArticleImage from '@/components/ArticleImage';

    const JobsToBeDonePage = () => {
      const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { staggerChildren: 0.1, delayChildren: 0.2 },
        },
      };

      const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: { type: 'spring', stiffness: 100 },
        },
      };

      return (
        <>
          <Helmet>
            <title>Jobs-to-be-Done: Are You Solving the Right Problem?</title>
            <meta name="description" content="Learn how to apply the Jobs-to-be-Done framework to uncover real user motivations. Insights from Itaú’s digital banking transformation in Brazil and Meetingselect’s self-booking platform in the Netherlands." />
          </Helmet>
          <div className="pt-24 md:pt-32 pb-24 px-6 overflow-hidden bg-black text-white">
            <motion.article
              initial="hidden"
              animate="visible"
              variants={containerVariants}
              className="max-w-3xl mx-auto"
            >
              <motion.header variants={itemVariants} className="mb-12 text-left">
                <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6 leading-[1.3] pb-3 text-[var(--color-highlight-blue)]">
                  Jobs-to-be-Done: Are You Solving the Right Problem?
                </h1>
                <div className="flex items-start flex-col sm:flex-row sm:items-center flex-wrap gap-x-6 gap-y-2 text-white/60 text-sm">
                  <div className="flex items-center gap-2">
                    <User size={14} />
                    <span>Amanda</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={14} />
                    <time dateTime="2025-09-05">September 05, 2025</time>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag size={14} />
                    <span>User Research, Strategy, JTBD</span>
                  </div>
                </div>
              </motion.header>

              <ArticleImage 
                src="https://images.unsplash.com/photo-1552581234-26160f608093" 
                alt="Team analyzing customer insights in a product strategy workshop."
                caption="Uncovering the real 'job' users are hiring your product to do."
              />

              <motion.div variants={itemVariants} className="prose prose-invert lg:prose-xl max-w-none mx-auto text-[var(--color-secondary-text)] space-y-8">
                <p className="lead text-xl md:text-2xl !text-white/90 leading-relaxed mb-8">
                  The Jobs-to-be-Done (JTBD) framework starts with a simple question: what is the user really trying to accomplish?
                </p>
                <p className="leading-relaxed text-base mb-8">
                  Clay Christensen’s “milkshake story” illustrates it clearly. A fast-food chain wanted to improve milkshake sales. After interviewing real customers, they learned that commuters were hiring milkshakes to make their long drives more enjoyable and to stay full until lunch. Once they understood the job, the solution changed. The shakes became thicker, the service faster, and the stores opened earlier.
                </p>
                <p className="leading-relaxed text-base mb-8">
                  I have seen the same principle in very different contexts, from Itaú’s digital banking transformation in Brazil to Meetingselect’s SaaS evolution in the Netherlands. JTBD is not just a framework, it is a mindset that helps uncover what users truly need to achieve.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 leading-[1.3] pb-3 mb-6">1. Understanding Needs, Motivations, and Jobs</h2>
                <p className="leading-relaxed text-base mb-8">
                  Traditional research often focuses on needs or pain points. JTBD goes deeper. Needs describe what users ask for. Motivations explain why they ask for it. Jobs reveal what they are truly trying to achieve.
                </p>
                <p className="leading-relaxed text-base mb-8">
                  During Itaú’s digital transformation between 2015 and 2019, the shift from paper-based to digital services expanded the bank’s customer base from about 8 million to 15 million digital users. By 2019, more than 60 percent of new accounts were opened entirely online. Customers were not just opening accounts. They were looking for faster and more reliable access to their money and financial control. That realization influenced how the teams prioritized improvements such as onboarding design, digital signatures, and instant verification.
                </p>
                <p className="leading-relaxed text-base mb-8">
                  At Meetingselect we apply the same thinking to understand our bookers, professionals who organize meetings and events for their companies. Bookers are not simply booking venues. Their real job is to keep the company organized, compliant, and cost efficient while delivering a smooth experience. Our platform is an end to end self booking solution for meetings and events. It centralizes bookings and helps organizations reduce costs and carbon footprint. Recognizing that job has guided how we shape product priorities, focusing on visibility, automation, and future sustainability features that empower bookers to make smarter and more responsible choices.
                </p>

                <ArticleImage 
                  src="https://images.unsplash.com/photo-1693027407605-ea314ec6cd77"
                  alt="Diagram showing the relationship between user jobs, outcomes, and context."
                  caption="JTBD helps connect user motivations to tangible product outcomes."
                />

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 leading-[1.3] pb-3 mb-6">2. How to Run JTBD Interviews</h2>
                <p className="leading-relaxed text-base mb-8">
                  JTBD interviews uncover real decision patterns rather than opinions.
                </p>
                <ul className="list-disc pl-5 space-y-2 mb-8 text-base">
                  <li className="leading-relaxed"><strong>Step 1: Map the timeline.</strong> Ask when the need first appeared, what triggered it, and how the decision evolved. You are mapping behavior, not preferences.</li>
                  <li className="leading-relaxed"><strong>Step 2: Go beyond demographics.</strong> A job gives more clarity than a persona. A description like “a booker in Amsterdam” is vague. A “booker who needs to secure a last-minute hybrid venue while meeting ESG and budget targets” provides context.</li>
                  <li className="leading-relaxed"><strong>Step 3: Identify emotional and functional drivers.</strong> Jobs always have emotional elements. At Itaú, one of the strongest drivers for mobile banking adoption was trust. People wanted to feel the same security online as they did at a branch. At Meetingselect, bookers value confidence and control. They want visibility and reassurance that every booking aligns with company goals.</li>
                  <li className="leading-relaxed"><strong>Step 4: Find recurring patterns.</strong> Group similar motivations and obstacles to reveal where the biggest opportunities are. In one case, Meetingselect bookers consistently said that speed of quoting was more valuable than the number of venue options. That insight redirected the roadmap to improve quote times, which directly increased conversion and satisfaction.</li>
                </ul>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 leading-[1.3] pb-3 mb-6">3. Turning Insights into Product Requirements</h2>
                <p className="leading-relaxed text-base mb-8">
                  JTBD insights only create value when they influence what the product team builds. Translate each job into three levels of outcomes.
                </p>
                <ul className="list-disc pl-5 space-y-2 mb-8 text-base">
                  <li className="leading-relaxed"><strong>Functional:</strong> What users want to achieve.</li>
                  <li className="leading-relaxed"><strong>Emotional:</strong> How they want to feel.</li>
                  <li className="leading-relaxed"><strong>Social:</strong> How they want to be perceived.</li>
                </ul>
                <p className="leading-relaxed text-base mb-8">
                  <strong>Example:</strong>
                </p>
                <p className="leading-relaxed text-base mb-8">
                  Job: Find and book a venue quickly.
                </p>
                <p className="leading-relaxed text-base mb-8">
                  Functional outcome: Save time comparing options.
                </p>
                <p className="leading-relaxed text-base mb-8">
                  Emotional outcome: Feel confident and in control.
                </p>
                <p className="leading-relaxed text-base mb-8">
                  Social outcome: Be seen as reliable and efficient.
                </p>
                <p className="leading-relaxed text-base mb-8">
                  At Itaú, these insights inspired improvements in clarity, onboarding communication, and notifications. At Meetingselect, the same approach informs ongoing enhancements focused on giving bookers more visibility and support to make efficient and sustainable booking decisions.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 leading-[1.3] pb-3 mb-6">Conclusion</h2>
                <p className="leading-relaxed text-base mb-8">
                  When you understand the job, you stop guessing features. JTBD connects empathy with structure and helps teams build products that truly solve user challenges. Whether it is digital banking in Brazil or booking management in Europe, success comes from understanding what users hire your product to do, not what they say they want.
                </p>
              </motion.div>

              <motion.div variants={itemVariants} className="mt-16 pt-8 border-t border-[var(--color-border-subtle)] bg-white/5 p-8 rounded-xl text-center">
                <p className="text-xl font-semibold text-white mb-4">
                  Discover how understanding user jobs accelerated platform growth and adoption.
                </p>
                <Link to="/insights/scaling-a-saas-platform" className="group inline-flex items-center font-bold text-[var(--color-highlight-blue)] hover:text-[var(--color-hover-blue)] transition-colors text-lg">
                  Read next: Scaling a SaaS Platform: Lessons from Real Growth Stories
                  <ArrowRight size={20} className="ml-2 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            </motion.article>
          </div>
        </>
      );
    };
    export default JobsToBeDonePage;