import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, User, Tag } from 'lucide-react';
import ArticleImage from '@/components/ArticleImage';
const ItauCaseStudyPage = () => {
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  const itemVariants = {
    hidden: {
      y: 20,
      opacity: 0
    },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };
  return <>
          <Helmet>
            <title>Revamping Itaú Unibanco’s Legacy System with Design Thinking</title>
            <meta name="description" content="How design thinking and automation transformed Itaú Unibanco’s operations between 2015 and 2019, reducing manual work by 40% and boosting user satisfaction with a 90% NPS goal." />
          </Helmet>
          <div className="pt-24 md:pt-32 pb-24 px-6 overflow-hidden bg-black text-white">
            <motion.article initial="hidden" animate="visible" variants={containerVariants} className="max-w-3xl mx-auto">
              <motion.header variants={itemVariants} className="mb-12 text-left">
                <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6 leading-[1.3] pb-3 text-white">
                  Revamping Itaú Unibanco’s Legacy System with Design Thinking
                </h1>
                <div className="flex items-start flex-col sm:flex-row sm:items-center flex-wrap gap-x-6 gap-y-2 text-white/60 text-sm">
                  <div className="flex items-center gap-2">
                    <User size={14} />
                    <span>Amanda</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={14} />
                    <time dateTime="2025-08-18">August 18, 2025</time>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag size={14} />
                    <span>Design Thinking, UX, Enterprise, Process Automation</span>
                  </div>
                </div>
              </motion.header>

              <ArticleImage src="https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/sqaud-itau-AYU2d.png" alt="Operations team analyzing process maps at Itaú Unibanco using design thinking." caption="Our operations team applying design thinking to map out legacy workflows." />

              <motion.div variants={itemVariants} className="prose prose-invert lg:prose-xl max-w-none mx-auto text-[var(--color-secondary-text)] space-y-4">
                <p className="lead text-xl md:text-2xl !text-white/90 leading-relaxed !mb-8">
                  Between 2015 and 2019, Itaú Unibanco led one of Brazil’s most ambitious digital transformation programs. The goal was to modernize its operational backbone, reduce complexity, and apply user-centered thinking to large-scale processes.
                </p>
                <p className="leading-relaxed text-base">I worked with C-levels, digital and operations teams to redesign legacy systems that supported thousands of daily routines. Many of these processes were essential but outdated. Teams executed repetitive tasks without understanding their purpose, leading to inefficiency and disengagement.</p>
                <p className="leading-relaxed text-base">
                  Our mission was to automate intelligently and bring purpose back to everyday work.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 !mt-12 !mb-6 leading-[1.3] pb-2">1. The Challenge: Legacy Routines and Operational Debt</h2>
                <p className="leading-relaxed text-base">
                  Itaú’s operations relied on legacy workflows built over decades. Manual data validation, repetitive approvals, and redundant systems were still part of everyday life.
                </p>
                <p className="leading-relaxed text-base">The deeper issue was structural. Many employees followed procedures that no one could explain anymore. Processes existed simply because “they had always been done that way.” This created operational debt, hidden inefficiencies embedded in routine work.</p>
                 <p className="leading-relaxed text-base">
                  One team alone spent nearly three hours per day copying information between systems for internal controls. Multiplied across hundreds of employees, the cost of inefficiency was significant.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 !mt-12 !mb-6 leading-[1.3] pb-2">2. Approach: Design Thinking Meets Process Automation</h2>
                <p className="leading-relaxed text-base">
                   To address the issue, we applied design thinking as the foundation for change. In 2016, we launched a six-week discovery sprint with operations, IT, and compliance teams. The goal was to understand behaviors, pain points, and root causes before proposing automation.
                </p>
                <p className="leading-relaxed text-base">
                  Through interviews, process shadowing, and journey mapping, we identified more than 70 manual steps across critical workflows that could be simplified or eliminated.
                </p>
                 <p className="leading-relaxed text-base">
                   We reframed automation as a human experience challenge, asking what outcomes employees were truly trying to achieve and what stood in their way. This approach aligned technology with purpose instead of replacing people with systems.
                </p>

                <ArticleImage src="https://images.unsplash.com/photo-1581291518570-03a26006fb21" alt="Automation workflow visualizing the transformation of Itaú Unibanco’s legacy processes." caption="Visualizing the new, automated workflow to align teams and stakeholders." />

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 !mt-12 !mb-6 leading-[1.3] pb-2">3. Implementation: Automating What Matters</h2>
                <p className="leading-relaxed text-base">
                  Between 2017 and 2018, we implemented a roadmap of 12 automation projects across multiple business units with measurable results. Key outcomes included:
                </p>
                <ul className="list-disc pl-5 space-y-2 !my-6 text-base">
                  <li className="leading-relaxed">40% reduction in manual data transfer tasks.</li>
                  <li className="leading-relaxed">Average case handling time reduced from 2 hours to 8 minutes.</li>
                  <li className="leading-relaxed">30% decrease in operational errors and rework.</li>
                  <li className="leading-relaxed">Internal satisfaction (NPS among process users) increased from +25 to +60, with a target of 90% satisfaction defined as part of the transformation roadmap.</li>
                </ul>
                <p className="leading-relaxed text-base">
                  One automation replaced a daily reconciliation routine that analysts previously performed manually. The new system ran the process each morning, flagged exceptions, and emailed results automatically. This freed teams to focus on decisions instead of repetition.
                </p>
                
                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 !mt-12 !mb-6 leading-[1.3] pb-2">4. Cultural Change: From Execution to Understanding</h2>
                <p className="leading-relaxed text-base">Automation had become part of Itaú’s continuous improvement culture. Teams started asking “why” before asking “how.”</p>
                <p className="leading-relaxed text-base">We launched a Process Innovation that showcased before-and-after process maps and recognized employee-driven improvements. Within six months, over 50 new optimization ideas came directly from front-line teams who had participated in earlier redesigns.</p>
                 <p className="leading-relaxed text-base">The transformation turned automation into a shared value, a mindset of clarity, accountability, and innovation.</p>
                
                <div className="bg-white/5 border border-[var(--color-border-subtle)] rounded-xl p-8 my-12">
                   <h3 className="text-2xl font-bold text-white mb-4">Transforming Financial Services Through Digital Innovation</h3>
                   <p className="text-[var(--color-secondary-text)] leading-relaxed text-base mb-4">
                     I led digital transformation initiatives at one of the world’s largest financial institutions, shaping product vision and delivering large-scale solutions for millions of users. The work improved service quality, reduced complaints, and mitigated risks, contributing to projects that generated over €370 million in results and supported a portfolio worth around €2.6 billion.
                   </p>
                   <Link to="/insights/rice-framework-feature-prioritization" className="group inline-flex items-center font-bold text-[var(--color-highlight-blue)] hover:text-[var(--color-hover-blue)] transition-colors text-base">
                      Learn how we prioritized features using the RICE framework
                      <ArrowRight size={16} className="ml-2 transform group-hover:translate-x-1 transition-transform" />
                   </Link>
                </div>


                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4 !mt-12 !mb-6 leading-[1.3] pb-2">Conclusion</h2>
                <p className="leading-relaxed text-base">
                  Revamping Itaú Unibanco’s legacy systems was not only a technical project, it was a shift in mindset. The initiative combined design thinking, automation, and cultural change to rebuild processes with purpose.
                </p>
                <p className="leading-relaxed text-base">
                  The results were measurable and human. Efficiency improved by 40 percent, satisfaction grew toward a 90 percent NPS goal, and teams gained confidence to question, simplify, and redesign their own workflows.
                </p>
                <p className="leading-relaxed text-base">
                  The project proved that true transformation happens when technology and empathy evolve together.
                </p>
              </motion.div>

              <motion.div variants={itemVariants} className="mt-16 pt-8 border-t border-[var(--color-border-subtle)] bg-white/5 p-8 rounded-xl text-center">
                <p className="text-xl font-semibold text-white mb-4">
                  Explore how user insights and process design drive transformation.
                </p>
                <Link to="/insights/jobs-to-be-done-right-problem" className="group inline-flex items-center font-bold text-[var(--color-highlight-blue)] hover:text-[var(--color-hover-blue)] transition-colors text-lg">
                  Read next: Jobs-to-be-Done: Are You Solving the Right Problem?
                  <ArrowRight size={20} className="ml-2 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            </motion.article>
          </div>
        </>;
};
export default ItauCaseStudyPage;