import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Tag } from 'lucide-react';
import ArticleImage from '@/components/ArticleImage';
const RicamConsultingPage = () => {
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  const itemVariants = {
    hidden: {
      y: 20,
      opacity: 0
    },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };
  const tags = ['Leadership', 'Strategy', 'Consulting', 'Product Transformation'];
  return <>
          <Helmet>
            <title>What Working with Latin America’s Most Followed Business Influencer Taught Me</title>
            <meta name="description" content="Lessons from my time at Ricam Consulting with Ricardo Amorim on clarity, consistency, and how strategic thinking translates into measurable digital transformation results." />
          </Helmet>
          <div className="pt-24 md:pt-32 pb-24 px-6 overflow-hidden bg-[var(--color-main-bg)] text-[var(--color-secondary-text)]">
            <motion.article initial="hidden" animate="visible" variants={containerVariants} className="max-w-3xl mx-auto">
              <motion.header variants={itemVariants} className="mb-12 text-left">
                <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6 leading-[1.3] pb-3 text-[var(--color-highlight-blue)]">
                  What working with Latin America’s most followed person on LinkedIn taught me
                </h1>
                <div className="flex items-start flex-wrap gap-x-3 gap-y-2 text-[var(--color-secondary-text)] text-sm">
                  {tags.map(tag => <div key={tag} className="flex items-center gap-2 text-sm border border-[var(--color-border-subtle)] rounded-full px-3 py-1">
                      <Tag size={14} className="text-[var(--color-highlight-blue)]" />
                      <span>{tag}</span>
                    </div>)}
                </div>
              </motion.header>

              <ArticleImage src="https://horizons-cdn.hostinger.com/f237bbd8-6c64-48fe-8ae9-bacce494670c/5e925ef557feefd83066b37a5f20205e.png" alt="LinkedIn profile of Ricardo Amorim, a prominent business influencer." caption="Ricardo Amorim: Latin America's most followed business influencer on LinkedIn." />

              <motion.div variants={itemVariants} className="prose prose-invert lg:prose-xl max-w-none mx-auto text-[var(--color-secondary-text)] space-y-10">
                <p className="lead text-xl md:text-2xl !text-[var(--color-heading-text)]/90 leading-relaxed">Early in my career, I had the opportunity to work with Ricardo Amorim, Latin America’s most followed influencer on LinkedIn and one of the region’s most respected economists. At Ricam Consulting, I learned how influence, strategy, and execution come together to create measurable outcomes. These lessons shaped how I lead digital transformation and product initiatives today.</p>

                <div>
                  <h2 className="!text-3xl md:!text-4xl font-bold !text-[var(--color-highlight-blue)] !mb-4">Clarity Creates Influence</h2>
                  <p className="text-base leading-relaxed">Working with someone whose ideas reached millions taught me that clarity matters more than visibility. Strategy only delivers results when people understand it and can act on it.</p>
                  <p className="text-base leading-relaxed">At Ricam Consulting, I saw how complex economic insights were translated into concrete actions for large organizations. Clients used those insights to redefine growth, open new digital channels, and strengthen their competitive position. That experience shaped how I now approach product strategy, making complex ideas simple so teams can deliver confidently.</p>
                </div>

                <div>
                  <h2 className="!text-3xl md:!text-4xl font-bold !text-[var(--color-highlight-blue)] !mb-4">Consistency Builds Credibility</h2>
                  <p className="text-base leading-relaxed">The team’s discipline around research, validation, and timing taught me that influence comes from consistent delivery. In business, credibility is not built by exposure but by proof of impact.</p>
                  <p className="text-base leading-relaxed">Later, while leading digital initiatives at Itaú Unibanco, I applied the same principle. The transformation of legacy processes led to a 40 percent reduction in manual work and over €370 million in measurable results across portfolios worth €2.6 billion. Real credibility comes from results, not visibility.</p>
                </div>

                <div>
                  <h2 className="!text-3xl md:!text-4xl font-bold !text-[var(--color-highlight-blue)] !mb-4">Every Strategy Needs a Story</h2>
                  <p className="text-base leading-relaxed">At Ricam Consulting, I learned that every digital initiative must have a clear narrative that unites teams and stakeholders. If people do not understand the purpose behind change, execution will always fall short.</p>
                  <p className="text-base leading-relaxed">When I moved into product strategy, I applied that same thinking at Meetingselect, a global SaaS platform with more than 500,000 venues across 150+ countries. My focus was on aligning product vision, market positioning, and user needs to strengthen the platform’s value proposition. This work supported the company’s expansion into new markets and reinforced its position as a global leader in meetings and events management.</p>
                </div>
                
                <div>
                   <h2 className="!text-3xl md:!text-4xl font-bold !text-[var(--color-highlight-blue)] !mb-4">Hybrid Thinking Drives Growth</h2>
                   <p className="text-base leading-relaxed">Working with economists, marketers, and strategists under one roof showed me the power of hybrid thinking. Combining analytical precision with creativity leads to better decisions and more sustainable growth.</p>
                   <p className="text-base leading-relaxed">Today, I use that mindset to connect data, design, and strategy to deliver measurable outcomes across digital ecosystems.</p>
                </div>

                <div>
                    <h2 className="!text-3xl md:!text-4xl font-bold !text-[var(--color-highlight-blue)] !mb-4">Conclusion</h2>
                    <p className="text-base leading-relaxed">Collaborating with one of Latin America’s most influential business figures taught me that real influence is built on clarity, consistency, and purpose. When strategy, story, and measurable results align, ideas move from vision to impact.</p>
                </div>
              </motion.div>
              
              <motion.div variants={itemVariants} className="mt-20 pt-8 border-t border-[var(--color-border-subtle)] text-center">
                <p className="text-xl font-semibold text-white mb-4">Read Next</p>
                <Link to="/insights/itau-unibanco-legacy-system-design-thinking" className="group inline-flex items-center font-bold text-[var(--color-highlight-blue)] hover:text-[var(--color-hover-blue)] transition-colors text-lg">
                  See how clarity and strategy created measurable results → Itaú Unibanco Case Study
                  <ArrowRight size={20} className="ml-2 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>

            </motion.article>
          </div>
        </>;
};
export default RicamConsultingPage;