
import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { Link } from 'react-router-dom';
    import { ArrowRight, Calendar, User, Tag } from 'lucide-react';
    import ArticleImage from '@/components/ArticleImage';

    const AiInProductManagementPage = () => {
      const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { staggerChildren: 0.1, delayChildren: 0.2 },
        },
      };

      const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: { type: 'spring', stiffness: 100 },
        },
      };

      return (
        <>
          <Helmet>
            <title>Lessons Learned from an AI Product Launch</title>
            <meta name="description" content="Key takeaways from bringing an AI-driven product to market and insights on navigating the hype." />
          </Helmet>
          <div className="pt-24 md:pt-32 pb-24 px-6 overflow-hidden bg-black text-white">
            <motion.article
              initial="hidden"
              animate="visible"
              variants={containerVariants}
              className="max-w-3xl mx-auto"
            >
              <motion.header variants={itemVariants} className="mb-12 text-center">
                <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6 text-white">
                  Lessons Learned from an AI Product Launch
                </h1>
                <div className="flex justify-center items-center flex-wrap gap-x-6 gap-y-2 text-white/60 text-sm">
                  <div className="flex items-center gap-2">
                    <User size={14} />
                    <span>Amanda</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={14} />
                    <time dateTime="2025-09-16">September 16, 2025</time>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag size={14} />
                    <span>AI, Product Launch, Strategy</span>
                  </div>
                </div>
              </motion.header>

              <ArticleImage 
                src="https://images.unsplash.com/photo-1678413340899-c01b1509a7a9?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" 
                alt="AI-driven product launch team meeting" 
                caption="Navigating the complexities of launching an AI product."
              />

              <motion.div variants={itemVariants} className="prose prose-invert lg:prose-xl max-w-none mx-auto text-[var(--color-secondary-text)] space-y-8">
                <p className="lead text-xl md:text-2xl !text-white/90 leading-relaxed">
                  Launching an AI-driven product is more than a technical challenge; it's an exercise in managing expectations, navigating hype, and focusing on real user value. Here are some key takeaways from bringing an AI product to market.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">1. Define a Narrow, Valuable Problem</h2>
                <p className="text-base leading-relaxed">
                  The promise of AI is vast, which can lead to unfocused product goals. The most successful AI products solve a very specific and high-value problem. Instead of "automating marketing," we focused on "reducing response time for high-intent leads." This clarity guided our model training, UI design, and success metrics.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">2. The "Human-in-the-Loop" is Your Greatest Asset</h2>
                <p className="text-base leading-relaxed">
                  Full automation is a tempting goal, but often impractical and undesirable at launch. We designed our system with a strong "human-in-the-loop" component. Users could review, edit, and approve AI-generated suggestions. This not only built user trust but also provided invaluable training data for improving the model over time.
                </p>
                
                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">3. Communicate Capabilities (and Limitations) Clearly</h2>
                <p className="text-base leading-relaxed">
                  AI is not magic. Setting realistic expectations is crucial. We were transparent about what the AI could and could not do. Onboarding materials and UI copy explicitly highlighted potential inaccuracies and encouraged user oversight. This preempted frustration and positioned the AI as a smart assistant, not an infallible oracle.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">4. Prioritize Data Quality Over Algorithm Complexity</h2>
                <p className="text-base leading-relaxed">
                  A sophisticated algorithm fed with poor-quality data will produce poor-quality results. We spent more time on data cleaning, labeling, and pipeline integrity than on tweaking the model itself. A simpler model with high-quality data consistently outperformed a complex one with messy data.
                </p>

                <h2 className="!text-3xl md:!text-4xl font-bold text-white border-l-4 border-[var(--color-highlight-blue)] pl-4">Conclusion</h2>
                <p className="text-base leading-relaxed">
                  Launching an AI product taught us that success lies at the intersection of user needs, data quality, and transparent communication. The hype around AI is a powerful tailwind, but lasting value comes from solving real-world problems reliably and ethically.
                </p>
              </motion.div>

              <motion.div variants={itemVariants} className="mt-16 pt-8 border-t border-[var(--color-border-subtle)] bg-white/5 p-8 rounded-xl text-center">
                <p className="text-xl font-semibold text-white mb-4">
                  Explore another case study on digital transformation.
                </p>
                <Link to="/insights/itau-unibanco-legacy-system-design-thinking" className="group inline-flex items-center font-bold text-[var(--color-highlight-blue)] hover:text-[var(--color-hover-blue)] transition-colors text-lg">
                  Read next: How Design Thinking Reshaped a Legacy System
                  <ArrowRight size={20} className="ml-2 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            </motion.article>
          </div>
        </>
      );
    };
    export default AiInProductManagementPage;
