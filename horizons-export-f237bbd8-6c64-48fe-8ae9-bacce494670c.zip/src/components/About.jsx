import React from 'react';
import { motion } from 'framer-motion';
import { Rocket, Lightbulb, BarChart, Users, ArrowRight, Mail, Linkedin, Briefcase, Building, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

const About = ({ content, scrollToContact }) => {
  const iconMap = {
    Rocket: Rocket,
    Lightbulb: Lightbulb,
    BarChart: BarChart,
    Users: Users,
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } },
  };
  
  const journeySteps = [
    {
      icon: Briefcase,
      title: "Entrepreneurship",
      description: "Founded and scaled my own business from the ground up, later acquired."
    },
    {
      icon: Building,
      title: "Fortune 500 Leadership",
      description: "Led large-scale digital initiatives for Fortune 500 banks including Itaú Unibanco and Bradesco."
    },
    {
      icon: Zap,
      title: "Strategic Consulting",
      description: "Shaped go-to-market strategies with Ricam Consulting for global clients such as Amazon, Samsung, Volvo, and KPMG."
    }
  ];

  return (
    <section id="about" className="py-24 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <div
          className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-20 items-start"
        >
          <motion.div variants={itemVariants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.1 }} className="lg:col-span-2 relative aspect-[4/5] rounded-3xl overflow-hidden border border-white/10 shadow-xl shadow-blue-900/10 lg:sticky lg:top-28">
            <img
              alt={`${content.name} - Digital Product Expert`}
              className="w-full h-full object-cover"
              src={content.imageUrl}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/10"></div>
          </motion.div>
          
          <motion.div variants={itemVariants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.1 }} className="lg:col-span-3 flex flex-col space-y-16">
            <div>
              <h2 className="text-4xl md:text-5xl font-extrabold tracking-tighter mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600" style={{color: 'var(--color-highlight-blue)'}}>{content.title}</h2>
              <p className="text-xl md:text-2xl text-white/70 max-w-prose leading-relaxed">
                {content.intro}
              </p>
            </div>
            
            <div className="space-y-10">
              <h3 className="text-3xl md:text-4xl font-bold tracking-tight text-white">{content.journeyTitle}</h3>
              <div className="relative border-l-2 border-white/10 pl-10 space-y-12">
                 {journeySteps.map((step, index) => (
                  <motion.div 
                    key={index}
                    className="relative"
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.5 }}
                    transition={{ duration: 0.6, delay: index * 0.2 }}
                  >
                    <div className="absolute -left-[41px] top-1 h-4 w-4 rounded-full bg-[var(--color-highlight-blue)] border-4 border-black"></div>
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-white/5 border border-white/10 rounded-lg">
                        <step.icon className="h-6 w-6 text-[var(--color-highlight-blue)]" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xl text-white">{step.title}</h4>
                        <p className="text-white/70 mt-1 text-base leading-relaxed">{step.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
               <p className="pl-10 text-white/80 text-lg leading-relaxed">{content.journeyText}</p>
            </div>

            <div className="flex flex-wrap gap-4 items-center pt-6">
              <Button
                onClick={() => scrollToContact('contact')}
                aria-label="Contact Me"
              >
                Contact Me
                <ArrowRight size={20} className="ml-2" />
              </Button>
              <motion.a
                href={`mailto:${content.email}`}
                whileHover={{ scale: 1.05, color: 'var(--color-highlight-blue)' }}
                whileTap={{ scale: 0.95 }}
                className="inline-flex items-center gap-2 text-white/70 font-semibold text-lg group transition-colors"
              >
                <Mail size={22} />
                Email
              </motion.a>
              <motion.a
                href="https://www.linkedin.com/in/amandadoliveiras/"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05, color: 'var(--color-highlight-blue)' }}
                whileTap={{ scale: 0.95 }}
                className="inline-flex items-center gap-2 text-white/70 font-semibold text-lg group transition-colors"
              >
                <Linkedin size={22} />
                LinkedIn
              </motion.a>
            </div>
          </motion.div>
        </div>

        <motion.div 
            className="pt-24 mt-20 border-t border-white/10"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-4xl md:text-5xl font-extrabold tracking-tighter mb-4" style={{color: 'var(--color-highlight-blue)'}}>{content.capabilitiesTitle}</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            {content.capabilities.map((cap, index) => {
              const Icon = iconMap[cap.iconName] || Lightbulb;
              return (
                <motion.div
                  key={index}
                  className="flex flex-col items-center text-center gap-4 p-6 rounded-2xl transition-all duration-300 bg-white/5 border border-transparent hover:border-white/10 hover:bg-white/10 hover:-translate-y-2"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 + index * 0.1 }}
                >
                  <div className="p-3 bg-[var(--color-highlight-blue)]/20 rounded-lg border border-[var(--color-highlight-blue)]/50">
                    <Icon size={28} className="text-[var(--color-highlight-blue)]" />
                  </div>
                  <span className="text-white font-bold text-lg leading-tight">{cap.text}</span>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

      </div>
    </section>
  );
};

export default About;