import React, { useState, useEffect } from 'react';
import { Outlet, useLocation, NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const Layout = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const logPageView = async () => {
      try {
        const { error } = await supabase
          .from('page_views')
          .insert({ path: location.pathname });

        if (error) {
          console.error('Error logging page view:', error.message);
        }
      } catch (error) {
        console.error('Exception when logging page view:', error);
      }
    };

    logPageView();
  }, [location.pathname]);

  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'Expertise', path: '/expertise' },
    { label: 'Insights', path: '/insights' },
    { label: 'About', hash: '#about' },
    { label: 'Work', hash: '#portfolio' },
    { label: 'Services', hash: '#services' },
    { label: 'Contact', hash: '#contact' },
  ];

  const scrollToSection = (hash) => {
    const element = document.getElementById(hash.substring(1));
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const handleNavClick = (item, e) => {
    if (location.pathname !== '/' && item.hash) {
      e.preventDefault();
      window.location.href = `/${item.hash}`;
    } else if (item.hash) {
      scrollToSection(item.hash);
    }
    setMobileMenuOpen(false);
  };
  
  const defaultFooter = "© 2025 Amanda. All rights reserved.";
  const expertiseFooter = "Digital product expert based in the Netherlands, specialized in product strategy, SaaS development, design thinking, customer journey mapping, NPS, and go-to-market execution. Experienced in leading global projects for Fortune 500 companies and fast-growing startups, transforming ideas into scalable digital solutions. Skilled in tools such as Jira, Confluence, HubSpot, Excel, Canva, PowerPoint, Figma, and Miro.";
  const footerText = location.pathname === '/expertise' ? expertiseFooter : defaultFooter;

  return (
    <div className="min-h-screen font-sans bg-[var(--color-main-bg)] text-[var(--color-secondary-text)] selection:bg-[var(--color-main-blue)] selection:text-white">
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="fixed top-0 left-0 right-0 z-50 bg-[var(--color-main-bg)]/50 backdrop-blur-lg border-b border-[var(--color-border-subtle)]"
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <NavLink to="/" className="text-2xl font-black tracking-tighter text-[var(--color-heading-text)] cursor-pointer">
            Amanda<span className="text-[var(--color-highlight-blue)]">.</span>
          </NavLink>
          <div className="hidden md:flex items-center gap-6">
            {navItems.map(item => (
              <NavLink
                key={item.label}
                to={item.path || '#'}
                onClick={(e) => handleNavClick(item, e)}
                className={({ isActive }) =>
                  `text-[var(--color-secondary-text)] hover:text-[var(--color-heading-text)] font-medium transition-colors ${isActive && !item.hash ? 'text-[var(--color-highlight-blue)]' : ''}`
                }
              >
                {item.label}
              </NavLink>
            ))}
             <motion.a whileHover={{ scale: 1.1 }} href="https://www.linkedin.com/in/amandadoliveiras/" target="_blank" rel="noopener noreferrer" className="text-[var(--color-secondary-text)] hover:text-[var(--color-heading-text)] font-medium transition-colors">
              LinkedIn
            </motion.a>
          </div>
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden text-[var(--color-heading-text)] p-2">
            {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-[var(--color-main-bg)]/90 backdrop-blur-xl border-t border-[var(--color-border-subtle)]"
            >
              <div className="px-6 py-4 space-y-4">
                {[...navItems, {label: "LinkedIn", href: "https://www.linkedin.com/in/amandadoliveiras/"}].map(item => (
                  item.href ? (
                    <motion.a key={item.label} whileTap={{ scale: 0.95 }} href={item.href} target="_blank" rel="noopener noreferrer" className="block w-full text-left text-[var(--color-heading-text)] hover:text-[var(--color-highlight-blue)] font-semibold py-2 transition-colors">
                      {item.label}
                    </motion.a>
                  ) : (
                    <NavLink
                      key={item.label}
                      to={item.path || '#'}
                      onClick={(e) => handleNavClick(item, e)}
                      className="block w-full text-left text-[var(--color-heading-text)] hover:text-[var(--color-highlight-blue)] font-semibold py-2 transition-colors"
                    >
                      {item.label}
                    </NavLink>
                  )
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      <Outlet />

      <footer className="border-t border-[var(--color-border-subtle)] py-8 px-6">
        <div className="max-w-7xl mx-auto text-center text-[var(--color-secondary-text)]/80">
          <p className={location.pathname === '/expertise' ? 'text-xs' : ''}>{footerText}</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;