import React from 'react';
    import { motion } from 'framer-motion';

    const ArticleImage = ({ src, alt, caption }) => {
      const imageVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.5, ease: 'easeOut' },
        },
      };

      return (
        <motion.figure 
          className="my-12 mx-auto max-w-[600px]"
          variants={imageVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.5 }}
        >
          <img src={src} alt={alt} className="w-full h-auto rounded-lg shadow-lg" loading="lazy" decoding="async" />
          {caption && (
            <figcaption className="mt-3 text-center text-sm text-[var(--color-secondary-text)] italic">
              {caption}
            </figcaption>
          )}
        </motion.figure>
      );
    };

    export default ArticleImage;