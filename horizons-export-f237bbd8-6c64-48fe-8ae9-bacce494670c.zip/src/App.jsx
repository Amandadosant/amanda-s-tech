import React from 'react';
        import { Routes, Route, useLocation } from 'react-router-dom';
        import HomePage from '@/pages/HomePage';
        import ExpertisePage from '@/pages/ExpertisePage';
        import FrameworksPage from '@/pages/FrameworksPage';
        import InsightsPage from '@/pages/InsightsPage';
        import ItauCaseStudyPage from '@/pages/articles/ItauCaseStudyPage';
        import RiceFrameworkPage from '@/pages/articles/RiceFrameworkPage';
        import RicamConsultingPage from '@/pages/articles/RicamConsultingPage';
        import ScalingSaaSPage from '@/pages/articles/ScalingSaaSPage';
        import JobsToBeDonePage from '@/pages/articles/JobsToBeDonePage';
        import AiInProductManagementPage from '@/pages/articles/AiInProductManagementPage';
        import Layout from '@/components/Layout';
        import { Toaster } from '@/components/ui/toaster';
        import { AuthProvider } from '@/contexts/SupabaseAuthContext';

        const App = () => {
          const location = useLocation();

          const externalRedirects = {
            '/insights/rice-framework-feature-prioritization': 'https://amandatech.site/insights/the-art-of-feature-prioritization-rice',
            '/insights/scaling-a-saas-platform': 'https://amandatech.site/insights/saas-scaling-growth-lessons',
            '/insights/ai-in-product-management': 'https://amandatech.site/insights/ai-product-launch-lessons',
            '/insights/jobs-to-be-done-right-problem': 'https://amandatech.site/insights/jobs-to-be-done-right-problem',
            '/insights/itau-unibanco-legacy-system-design-thinking': 'https://amandatech.site/insights/itau-unibanco-legacy-system-design-thinking',
            '/insights/working-with-latin-americas-most-followed-influencer': 'https://amandatech.site/insights/latin-america-influencer-ricardo-amorim'
          };

          if (externalRedirects[location.pathname] && !Object.values(externalRedirects).includes(window.location.href)) {
             if (window.location.href !== externalRedirects[location.pathname]) {
                window.location.href = externalRedirects[location.pathname];
                return null;
             }
          }
          
          return (
            <AuthProvider>
              <Routes>
                <Route path="/" element={<Layout />}>
                  <Route index element={<HomePage />} />
                  <Route path="expertise" element={<ExpertisePage />} />
                  <Route path="frameworks" element={<FrameworksPage />} />
                  <Route path="insights" element={<InsightsPage />} />
                  <Route path="/insights/itau-unibanco-legacy-system-design-thinking" element={<ItauCaseStudyPage />} />
                  <Route path="/insights/the-art-of-feature-prioritization-rice" element={<RiceFrameworkPage />} />
                  <Route path="/insights/latin-america-influencer-ricardo-amorim" element={<RicamConsultingPage />} />
                  <Route path="/insights/saas-scaling-growth-lessons" element={<ScalingSaaSPage />} />
                  <Route path="/insights/jobs-to-be-done-right-problem" element={<JobsToBeDonePage />} />
                  <Route path="/insights/ai-product-launch-lessons" element={<AiInProductManagementPage />} />
                </Route>
              </Routes>
              <Toaster />
            </AuthProvider>
          );
        };

        export default App;